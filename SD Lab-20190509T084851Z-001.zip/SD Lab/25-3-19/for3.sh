for i in {0..10..2}
do 
echo "welcome $i times"
done
