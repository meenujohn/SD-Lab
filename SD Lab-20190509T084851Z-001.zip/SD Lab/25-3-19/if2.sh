if [ "$1" == "Monday" ]
then 
echo "The typed argument is monday"
  elif [ "$1" == "tuesday" ]
  then
  echo "The typed argument is tuesday"
        else
        echo "The typed argument isneither monday nor tusday"
fi

  
