for ((;;)) 
do 
echo "infinite loops[hit ctrl+c to stop]"
done
