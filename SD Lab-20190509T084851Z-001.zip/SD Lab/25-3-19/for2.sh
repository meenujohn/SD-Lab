for i in {1..5}
do
   echo "welcome  $i times  "
done
