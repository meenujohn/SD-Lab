i=5
while test "$i" -gt 0
do
i=`expr $i - 1`
echo $i
done
